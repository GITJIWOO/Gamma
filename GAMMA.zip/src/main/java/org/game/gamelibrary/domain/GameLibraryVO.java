package org.game.gamelibrary.domain;

public class GameLibraryVO {

}
