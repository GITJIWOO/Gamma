package org.game.review.domain;

import lombok.Data;

@Data
public class ReviewLikeVO {
	
	private long rlnum;
	private long grnum;
	private String cid;
	
}
