package org.game.gamepurchase.controller;

public class GamePurchaseController {

}
