package org.game.gamepurchase.domain;

public class GamePurchaseVO {

}
