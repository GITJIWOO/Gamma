package org.game.gamepurchase.service;

public interface GamePurchaseService {

}
