package org.game.gamepurchase.mapper;

public interface GamePurchaseMapper {

}
