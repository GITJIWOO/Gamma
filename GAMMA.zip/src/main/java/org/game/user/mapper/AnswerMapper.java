package org.game.user.mapper;

public interface AnswerMapper {

}
