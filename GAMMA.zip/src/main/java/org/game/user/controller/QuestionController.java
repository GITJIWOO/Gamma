package org.game.user.controller;

import java.util.List;

import org.game.user.domain.QuestionPageDTO;
import org.game.user.domain.QuestionSearchCriteria;
import org.game.user.domain.QuestionVO;
import org.game.user.service.QuestionService;
import org.game.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/qna/*")
@AllArgsConstructor
public class QuestionController {
	@Autowired
	private QuestionService service;
	
	@Autowired
	private UserService uservice;
	
	// 질문글 작성하는 폼 
	@PostMapping("/questionform")
	public String addQuestion(String cid, Model model) {
		model.addAttribute("qwriter", cid);
		return "/qna/registerquestion";
	}
	
	// 작성한 질문글 등록하고 자신이 작성한 질문글 목록 조회
	@PostMapping("/registerquestion")
	public String registerQuestion(QuestionVO vo, RedirectAttributes rttr) {
		service.addQuestion(vo);
		rttr.addFlashAttribute("cid", vo.getQwriter());
		rttr.addFlashAttribute("qnum", vo.getQnum());
		rttr.addFlashAttribute("success", "register");	// 이걸로 모달 넣기
		return "redirect:/qna/questionlist";
	}
	
	// 질문글 목록 조회
	@GetMapping("/questionlist")
	public String questionList(String qwriter, QuestionSearchCriteria cri, Model model) {
		int admin = service.adminOrNot(qwriter);
		// 1이면 관리자, 0이면 일반회원
		if(admin == 1) {
			List<QuestionVO> vo = service.questionListP(cri, "%%");			
			model.addAttribute("vo", vo);
			QuestionPageDTO btnMaker = new QuestionPageDTO(cri, service.countQuestion("%%"), 10);
			model.addAttribute("btnMaker", btnMaker);
		}else {
			List<QuestionVO> vo = service.questionListP(cri, qwriter);
			model.addAttribute("vo", vo);
			QuestionPageDTO btnMaker = new QuestionPageDTO(cri, service.countQuestion(qwriter), 10);
			model.addAttribute("btnMaker", btnMaker);
		}
		model.addAttribute("admin", admin);
		model.addAttribute("qwriter", qwriter);
		return "/qna/questionlist";
	}
	
	// 질문글 수정
	@PostMapping("/modifyquestion")
	public String modifyQuestionForm(int qnum, Model model) {
		QuestionVO vo = service.ownQuestion(qnum);
		model.addAttribute("vo", vo);
		return "qna/modifyclear";
	}
	
	// 질문글 수정 완료
	@PostMapping("/modifyclear")
	public String modifyQuestion(QuestionVO vo, RedirectAttributes rttr) {
		service.modifyQuestion(vo);
		rttr.addFlashAttribute("success", "modify");
		rttr.addFlashAttribute("qnum", vo.getQnum());

		// 아래 주소로 넘길 때 post 이지만 파라미터 값으로 번호를 넘겨서 해당 번호 질문글 상세로 넘어가게 하려면? 
		return "redirect:/qna/getquestion";
	}
	
	// 질문글 상세 조회
	@PostMapping("/getquestion")
	public String getQuestion(int qnum, Model model) {
		QuestionVO vo = service.ownQuestion(qnum);
		model.addAttribute("vo", vo);
		return "/qna/getquestion";
	}
	
	// 질문글 삭제
	@PostMapping("/removequestion")
	public String removeQuestion(int qnum, RedirectAttributes rttr) {
		service.removeQuestion(qnum);
		rttr.addFlashAttribute("success", "remove");
		rttr.addFlashAttribute("qnum", qnum);
		return "redirect:/qna/questionlist";
	}
}