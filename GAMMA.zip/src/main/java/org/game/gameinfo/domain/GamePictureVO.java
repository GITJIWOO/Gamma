package org.game.gameinfo.domain;

import lombok.Data;

@Data
public class GamePictureVO {
	
	private String uuId;
	private long gNum;
	private String pictureNum;
	private String pictureTime;
}
