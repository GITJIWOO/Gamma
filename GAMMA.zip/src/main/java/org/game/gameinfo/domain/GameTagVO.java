package org.game.gameinfo.domain;

import lombok.Data;

@Data
public class GameTagVO {
	
	private long gtnum;
	private String tagname;
	private long gnum;
}
